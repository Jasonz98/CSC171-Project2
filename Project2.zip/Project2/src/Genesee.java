
public class Genesee {
    private int hole;
    private int yards;
    private int par;
    
    public Genesee(int hole, int yards, int par) {
    	this.hole = hole;
    	this.yards = yards;
    	this.par = par;
    }

	public int getHole() {
		return hole;
	}

	public void setHole(int hole) {
		this.hole = hole;
	}

	public int getYards() {
		return yards;
	}

	public void setYards(int yards) {
		this.yards = yards;
	}

	public int getPar() {
		return par;
	}

	public void setPar(int par) {
		this.par = par;
	}
	
    
    
}
